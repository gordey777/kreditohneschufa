<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

get_header();
?>

	<div id="content">
	<div class="page">
		<div class="container">
			
			
				
				<h1>404</h1>
				<div class="entry">
					<h2>Seite nicht gefunden </h2>
					<p><a href="/">zurück zur Startseite</a></p>
				
			</div>
		
		</div>
	</div>
</div>



<?php get_footer(); ?>